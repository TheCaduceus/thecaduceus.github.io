---
Open Commands.txt for Complete guide!
---
This Scripts comes with the Fix for getting 400 Login Error with Google "App doesn't compile with Google's Auth 2.0 Policy".

Updated & Fixed by
Dr.Caduceus
Update Channel:
https://t.me/TheCaduceusUPDATE
Website:
https://www.caduceus.ml/